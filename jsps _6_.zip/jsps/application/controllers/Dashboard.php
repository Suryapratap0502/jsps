<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
  
  public function __construct()

{

parent::__construct();

		$this->load->model('Dashboard_model');
		$this->load->helper('url');
 		$this->load->library('form_validation');
      	$this->load->library('session');
   
}
	public function index()
	{
		//$this->session->set('login', true);
		//check that whether the  session is set or not 
		if ($this->session->userdata('pmsadmin') == true) {
          	$data['total_employee'] = $this->Dashboard_model->total_employee();

			return $this->load->view('admin/index');
		} else {
			$this->session->set_flashdata('denied', 'Access Denied!');
			return $this->load->view('admin/login');
		}
	}

	public function logout()
	{

        $sess = $this->session->userdata('pmsadmin');
            $name = $sess['name'];
            $role = $sess['role'];
            $id = $sess['id'];
            date_default_timezone_set('Asia/Kolkata');
        	$date = date('d-m-Y H:i A');
			$this->db->query("UPDATE master_admin set last_login = '$date' WHERE admin_user_id = '$id'");
			session_destroy();
           unset($_SESSION);
           return $this->load->view('admin/logout');
	}

	public function notification()
	{
		$id = $_POST['id'];
		$update = array(
        'read_status'  => '1'
        );
         $sess = $this->session->userdata('pmsadmin');
         $name = $sess['name'];
         $role = $sess['role'];
      	 $this->db->where('member_created_to',$id);
        $this->db->update('notification',$update);
      	redirect($_SERVER['REQUEST_URI'], 'refresh'); 
	}
  
    

}
