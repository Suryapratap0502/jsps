<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends MY_Controller {

	
	public function __construct()

{

parent::__construct();

      	$this->load->model('report_model');
        $this->load->model('underwriter_model');
        $this->load->model('Form_model');
		$this->load->helper('url');
 		$this->load->library('form_validation');
      	$this->load->library('session');
      	$this->load->helper('email');
    

}
	public function fresh_operation($offset = null)
	{
	
		if ($this->session->userdata('pmsadmin') == true) {
            $short_name = $this->uri->segment(2);
          if($short_name == 'fresh_operation')
          {
            $short_name = 'operations';
          }
            $limit = 50;
            $offset = ($offset == null || $offset == 1) ? '0' : ($offset - 1) * ($limit);
            $data['fresh_operation'] = $this->report_model->list_common('form',$limit, $offset);
            $data['company'] = $this->Form_model->list_common('company');
            $data['team_leader'] = $this->Form_model->list_common('team_leader');
            $total = $this->report_model->report_data('form', 'flag', '0');
            $data['count'] = $total;
            $data['offset'] = (empty($offset) || $offset == 1) ? '1' : $offset + 1;
            $data1 = $this->underwriter_model->fetch_sidebar_group_id('sidebar_group','group_short_name',$short_name);
            foreach($data1 as $val){
                $data['disposition_name'] = $this->underwriter_model->fetch_sidebar_group_id('disposition','module',$val['sidebar_id']);
             
                 }
            
            return $this->load->view('admin/report/fresh_operation',$data);
         	
		} else {
			$this->session->set_flashdata('denied', 'Access Denied!');
			return $this->load->view('admin/login');
		}
		
	}

    public function service_report($offset = null)
    {
        if ($this->session->userdata('pmsadmin') == true) {
        $short_name = $this->uri->segment(2);
          if($short_name == 'service_report')
          {
            $short_name = 'services';
          }
            $limit = 50;
            $offset = ($offset == null || $offset == 1) ? '0' : ($offset - 1) * ($limit);
            $data['fresh_operation'] = $this->report_model->list_common('form',$limit, $offset);
            $data['company'] = $this->Form_model->list_common('company');
            $data['team_leader'] = $this->Form_model->list_common('team_leader');
            $total = $this->report_model->report_data('form', 'flag', '0');
            $data['count'] = $total;
            $data['offset'] = (empty($offset) || $offset == 1) ? '1' : $offset + 1;

            $data1 = $this->underwriter_model->fetch_sidebar_group_id('sidebar_group','group_short_name',$short_name);
          foreach($data1 as $val){
          	$data['disposition_name'] = $this->underwriter_model->fetch_sidebar_group_id('disposition','module',$val['sidebar_id']);
           
           	}
            
            return $this->load->view('admin/report/service_report',$data);
         	
		} else {
			$this->session->set_flashdata('denied', 'Access Denied!');
			return $this->load->view('admin/login');
		}
    }

    public function claim_dump_report($offset = null)
    {
        if ($this->session->userdata('pmsadmin') == true) {
           
                $limit = 50;
                $offset = ($offset == null || $offset == 1) ? '0' : ($offset - 1) * ($limit);
                $data['claim'] = $this->report_model->list_common('claim',$limit, $offset);
                $data['company'] = $this->Form_model->list_common('company');
                $total = $this->report_model->report_data('claim', 'flag', '0');
                $data['count'] = $total;
                
                $data['offset'] = (empty($offset) || $offset == 1) ? '1' : $offset + 1;
                return $this->load->view('admin/report/claim_report',$data);
                 
            } else {
                $this->session->set_flashdata('denied', 'Access Denied!');
                return $this->load->view('admin/login');
            }
    }

    public function renewal_booked_report($offset = null)
    {
        if ($this->session->userdata('pmsadmin') == true) {
           
            $limit = 50;
            $offset = ($offset == null || $offset == 1) ? '0' : ($offset - 1) * ($limit);
            $data['renewal'] = $this->report_model->renewal_report($limit, $offset);
           
            $data['company'] = $this->Form_model->list_common('company');
            $total = $this->report_model->report_data('sub_desposition', 'module', 'renewals');
            $data['count'] = $total;
            
            $data['offset'] = (empty($offset) || $offset == 1) ? '1' : $offset + 1;
            return $this->load->view('admin/report/renewal_report',$data);
             
        } else {
            $this->session->set_flashdata('denied', 'Access Denied!');
            return $this->load->view('admin/login');
        }
  
}

public function exportexcel($claim_intimation_no = 'claim')
	{
		

		header("Content-Type: application/xls");
		header("Content-Disposition: attachment; filename=" . $claim_intimation_no. ".xls");
		header("Pragma: no-cache");
		header("Expires: 0");

		echo '<table border="1">';

		
			echo '<tr>
            <th>S.No</th>
            <th>Policy No.</th>
            <th>Patient Name</th>
            <th>Company</th>
            <th>Claim Intimation No</th>
            <th>Reason For Admit</th>

            <th>Health Card</th>
            <th>Admission Date</th>
            <th>Network/Non Network</th>
            <th>Claim Type</th>
            <th>Claim For</th>
            <th>Pre Auth Status</th>

            <th>Pre Auth Amount</th>
            <th>Claim Status</th>
            <th>Total Bill Amount</th>
            <th>Total Approve Amount </th>
            <th>Hospital Discount</th>
            <th>Deduction Amount</th>

            <th>Deduction Amount Detail</th>
            <th>Paid on</th>
            <th>Remark</th>
            <th>Final Status</th>
            </tr>';

			$booth_details = $this->report_model->list_common('claim');

			if (!empty($booth_details)) {
				foreach($booth_details as $key => $row) {
					echo "<tr>
                        <td>" . $key +1 . "</td>
                        <td>" . $row['policy_no'] . "</td>
                        <td>" . $row['patient_name'] . "</td>
                        <td>" . $row['company_name'] . "</td>
                        <td>" . $row['reason_admit'] . "</td>

                        
                        <td>" . $row['health_card'] . "</td>
                        <td>" . $row['admission_date'] . "</td>
                        <td>" . $row['is_network'] . "</td>
                        <td>" . $row['claim_type'] . "</td>

                        <td>" . $row['claim_for'] . "</td>
                        <td>" . $row['pre_auth_status'] . "</td>
                        <td>" . $row['pre_auth_amt'] . "</td>
                        <td>" . $row['claim_status'] . "</td>

                        <td>" . $row['total_bill_amt'] . "</td>
                        <td>" . $row['total_approve_amt'] . "</td>
                        <td>" . $row['hospital_discount'] . "</td>
                        <td>" . $row['deduction_amt'] . "</td>

                        <td>" . $row['deduction_amt_details'] . "</td>
                        <td>" . $row['paid_on'] . "</td>
                        <td>" . $row['remarks'] . "</td>
                        <td>" . $row['final_status'] . "</td>
                    </tr>";
				}
			}
		

		echo '</table>';

		exit();
	}

    public function exportexcel_service($claim_intimation_no = 'services')
	{
		

		header("Content-Type: application/xls");
		header("Content-Disposition: attachment; filename=" . $claim_intimation_no. ".xls");
		header("Pragma: no-cache");
		header("Expires: 0");

		echo '<table border="1">';

		
			echo '<tr>
            <th>S.No</th>
                                                        <th>Policy No.</th>
                                                        <th>Log ID</th>
                                                        <th>Cust ID </th>
                                                        <th>Cust Name</th>
                                                        <th>Phone No.</th>

                                                        <th>Alternate No.</th>
                                                        <th>Email Id</th>
                                                        <th>City</th>
                                                        <th>D.O.B</th>
                                                        <th>Company Name</th>
                                                        <th>Product Name</th>

                                                        <th>Cover Type</th>
                                                        <th>Family Type</th>
                                                        <th>Sum Assured</th>
                                                        <th>Date </th>
                                                        <th>Premium</th>
                                                        <th>Net Premium</th>

                                                        <th>Counted Premium</th>
                                                        <th>Type</th>
                                                        <th>Term</th>
                                                        <th>Port Term</th>
                                                        <th>Zone</th>
                                                        <th>Agent</th>
                                                        <th>TL</th>
                                                        <th>Login</th>
                                                        <th>Disposition</th>
                                                        <th>Call Date</th>
            </tr>';

			$fresh_operation = $this->report_model->list_common_service('form');
			
			if (!empty($fresh_operation)) {
				foreach($fresh_operation as $key => $row) {
					echo "<tr>
                        <td>" . 1 . "</td>
                        <td>" .$row['policy_no']. "</td>
                        <td>" .$row['log_id']. "</td>
                        <td>" .$row['id'] . "</td>
                        <td>" .$row['customer_name']. "</td>

                        
                        <td>" .$row['contact']. "</td>
                        <td>" .$row['alternate_no']. "</td>
                        <td>" .$row['email']. "</td>
                        <td>" .$row['customer_city']. "</td>

                        <td>" .$row['dob']. "</td>
                        <td>" .$row['company_name']. "</td>
                        <td>" .$row['product_name']. "</td>
                        <td>" .$row['cover_type']. "</td>

                        <td>" .$row['coverage_type']. "</td>
                        <td>" .$row['sum_assured_1']. "</td>
                        <td>" .$row['created_at']. "</td>
                        <td>" .$row['gross_premium']. "</td>

                        <td>" .$row['net_premium']. "</td>
                        <td>" .$row['policy_type']. "</td>
                        <td>" .$row['payment_tenure']. "</td>
                       
                    </tr>";
				}
			}
		

		echo '</table>';

		exit();
	}
	 public function exportexcel_report_opration($claim_intimation_no = 'services')
	{
		

		header("Content-Type: application/xls");
		header("Content-Disposition: attachment; filename=" . $claim_intimation_no. ".xls");
		header("Pragma: no-cache");
		header("Expires: 0");

		echo '<table border="1">';

		
			echo '<tr>
            <th>S.No</th>
                                                        <th>S.No</th>
                                                        <th>Policy No.</th>
                                                        <th>Log ID</th>
                                                        <th>Cust ID </th>
                                                        <th>Cust Name</th>
                                                        <th>Phone No.</th>

                                                        <th>Alternate No.</th>
                                                        <th>Email Id</th>
                                                        <th>City</th>
                                                        <th>D.O.B</th>
                                                        <th>Company Name</th>
                                                        <th>Product Name</th>

                                                        <th>Cover Type</th>
                                                        <th>Family Type</th>
                                                        <th>Sum Assured</th>
                                                        <th>Date </th>
                                                        <th>Premium</th>
                                                        <th>Net Premium</th>

                                                        <th>Counted Premium</th>
                                                        <th>Type</th>
                                                        <th>Term</th>
                                                        <th>Port Term</th>
                                                        <th>Medical</th>
                                                        <th>Zone</th>

                                                        <th>Agent</th>
                                                        <th>TL</th>
                                                        <th>Login</th>
                                                        <th>Issued Date</th>

                                                        <th>PED</th>
                                                        <th>Discount</th>
                                                        <th>Rider</th>
                                                        <th>U/W Remark</th>
                                                        <th>Policy Enforced Date</th>
                                                        <th>Policy Start Date</th>
                                                        <th>Policy End Date</th>
                                                        <th>Policy Source</th>
            </tr>';

			//$fresh_operation = $this->report_model->list_common_service('form');
       $operation = $this->report_model->list_common('form');
			
			if (!empty($operation)) {
				foreach($operation as $key => $row) {
					echo "<tr>
                        <td>" . 1 . "</td>
                        <td>" .$row['policy_no']. "</td>
                        <td>" .$row['log_id']. "</td>
                        <td>" .$row['id'] . "</td>
                        <td>" .$row['customer_name']. "</td>

                        
                        <td>" .$row['contact']. "</td>
                        <td>" .$row['alternate_no']. "</td>
                        <td>" .$row['email']. "</td>
                        <td>" .$row['customer_city']. "</td>

                        <td>" .$row['dob']. "</td>
                        <td>" .$row['company_name']. "</td>
                        <td>" .$row['product_name']. "</td>
                        <td>" .$row['cover_type']. "</td>

                        <td>" .$row['coverage_type']. "</td>
                        <td>" .$row['sum_assured_1']. "</td>
                        <td>" .$row['created_at']. "</td>
                        <td>" .$row['gross_premium']. "</td>

                        <td>" .$row['net_premium']. "</td>
                        <td>" .$row['policy_type']. "</td>
                        <td>" .$row['payment_tenure']. "</td>
                        
                        <td>" .$row['portability_duration']. "</td>
                        <td>" .$row['medical']. "</td>
                        <td>" .$row['zone']. "</td>
                        <td>" .$row['customer_name']. "</td>
                        
                         <td>" .$row['tl']. "</td>
                        <td>" .$row['login']. "</td>
                        <td>" .$row['policy_issue_date']. "</td>
                        <td>" .$row['insured_1_ped']. "</td>
                        
                        <td>" .$row['discount']. "</td>
                        <td>" .$row['rider']. "</td>
                        <td>" .$row['remark']. "</td>
                        <td>" .$row['policy_start_date']. "</td>
                        
                        <td>" .$row['policy_end_date']. "</td>
                        <td>" .$row['policy_source']. "</td>
                        
                       
                    </tr>";
				}
			}
		

		echo '</table>';

		exit();
	}
	
   public function exportexcel_renawal_report($claim_intimation_no = 'services')
	{
		

		header("Content-Type: application/xls");
		header("Content-Disposition: attachment; filename=" . $claim_intimation_no. ".xls");
		header("Pragma: no-cache");
		header("Expires: 0");

		echo '<table border="1">';

		
			echo '<tr>
            <th>S.No</th>
                                                        <th>S.No</th>
                                                        <th>Customer Name</th>
                                                        <th>Policy</th>
                                                        <th>New Policy</th>
                                                        <th>Phone No.</th>
                                                        <th>Alternate No.</th>

                                                        <th>Alternate No.2</th>
                                                        <th>Email</th>
                                                        <th>City</th>
                                                        <th>Date Of Birth</th>
                                                        <th>Company Name</th>
                                                        <th>Product Name</th>

                                                        <th>Policy End Date</th>
                                                        <th>Payment Due On</th>
                                                        <th>Faimly Type</th>
                                                        <th>Sum Assured</th>
                                                        <th>Payment Date</th>
                                                        <th>Due Renewal</th>

                                                        <th>Paid Renewal</th>
                                                        <th>Upsell</th>
                                                        <th>Tenure1</th>
                                                        <th>Agent Name</th>
                                                        <th>Payment Mode</th>
                                                        <th>Discount</th>
                                                        <th>Upselling</th>
            </tr>';

			
     $renewal = $this->report_model->renewal_report();
			
			if (!empty($renewal)) {
				foreach($renewal as $key => $row) {
					echo "<tr>
                        <td>" . 1 . "</td>
                        <td>" .$row['customer_name']. "</td>
                        <td>" .$row['policy_no']. "</td>
                        <td>" .$row['New Policy'] . "</td>
                      

                        
                        <td>" .$row['contact']. "</td>
                        <td>" .$row['Alternate Number']. "</td>
                        <td>" .$row['alternate_no']. "</td>
                        <td>" .$row['email']. "</td>

                        <td>" .$row['customer_city']. "</td>
                        <td>" .$row['Proposer Date Of Birth']. "</td>
                        <td>" .$row['company_name']. "</td>
                        <td>" .$row['product_name']. "</td>

                        <td>" .$row['policy_end_date']. "</td>
                        <td>" .$row['coverage_type']. "</td>
                        <td>" .$row['New Sum Assured']. "</td>
                        <td>" .$row['New Payment Tenure']. "</td>

                        <td>" .$row['agent']. "</td>
                        <td>" .$row['New Payment Mode']. "</td>
                        <td>" .$row['New Discount']. "</td>
                        
                        <td>" .$row['Upselling']. "</td>
                       
                        
                       
                    </tr>";
				}
			}
		

		echo '</table>';

		exit();
	}
}

