<?php  $company = $this->Form_model->list_common('company');
            $team_leader = $this->Form_model->list_common('team_leader');
                                                    $i = 1;
                                                    if (!empty($fresh_operation)) {foreach ($fresh_operation as $row) {?>
                                                            <tr>
                                                            <td><?php echo $i; ?></td>
                                                                <td><?php if (!empty($row['policy_no'])) { ?><?php echo $row['policy_no'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['log_id'])) { ?><?php echo $row['log_id'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['id'])) { ?><?php echo $row['id'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['customer_name'])) { ?><?php echo $row['customer_name'] ?> <?php } else{ echo $row['proposer_name'];} ?></td>
                                                                <td><?php if (!empty($row['contact'])) { ?><?php echo $row['contact']; ?> <?php } ?></td>

                                                                <td><?php if (!empty($row['alternate_no'])) { ?><?php echo $row['alternate_no'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['email'])) { ?><?php echo $row['email'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['customer_city'])) { ?><?php echo $row['customer_city'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['dob'])) { ?><?php echo $row['dob'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['company_name'])) { ?><?php if($row['company_name']== $company[0]['id']){ echo $company[0]['name'];} ?> <?php } ?></td>

                                                                <td><?php if (!empty($row['product_name'])) { ?><?php echo $row['product_name'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['cover_type'])) { ?><?php echo $row['cover_type'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['coverage_type'])) { ?><?php echo $row['coverage_type'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['sum_assured_1'])) { ?><?php echo $row['sum_assured_1'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['created_at'])) { ?><?php echo $row['created_at']; ?> <?php } ?></td>

                                                                <td><?php if (!empty($row['gross_premium'])) { ?><?php echo $row['gross_premium'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['net_premium'])) { ?><?php echo $row['net_premium'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['net_premium'])) { ?><?php echo $row['net_premium'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['policy_type'])) { ?><?php echo $row['policy_type'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['payment_tenure'])) { ?><?php echo $row['payment_tenure']; ?> <?php } ?></td>

                                                                <td><?php if (!empty($row['portability_duration'])) { ?><?php echo $row['portability_duration'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['medical'])) { ?><?php echo $row['medical'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['zone'])) { ?><?php echo $row['zone'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['customer_name'])) { ?><?php echo $row['customer_name'] ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['tl'])) { ?><?php if($row['tl']== $team_leader[0]['id']){ echo $team_leader[0]['name'];} ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['login'])) { ?><?php echo $row['login']; ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['policy_issue_date'])) { ?><?php echo $row['policy_issue_date']; ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['insured_1_ped'])) { ?><?php echo $row['insured_1_ped']; ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['discount'])) { ?><?php echo $row['discount']; ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['rider'])) { ?><?php echo $row['rider']; ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['remark'])) { ?><?php echo $row['remark']; ?> <?php } ?></td>
                                                                <td>Policy Enforeced Date</td>
                                                                <td><?php if (!empty($row['policy_start_date'])) { ?><?php echo $row['policy_start_date']; ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['policy_end_date'])) { ?><?php echo $row['policy_end_date']; ?> <?php } ?></td>
                                                                <td><?php if (!empty($row['policy_source'])) { ?><?php echo $row['policy_source']; ?> <?php } ?></td>
                                                            </tr>
                                                        <?php $i++; } } else{ echo "No Data";} ?>