 <?php
if(!defined('BASEPATH')) exit('Hacking Attempt : Get Out of the system ..!');

class Dashboard_Model extends CI_Model

{

public function __construct()

{

parent::__construct();

}





public function total_employee()

{
   
  
    
}

public function countrow($table)
  {
    $fetch_pass = $this->db->query("select COUNT(id) as count from " . $table . " where flag != 2");
    $result = $fetch_pass->row();
    echo $res = $result->count;
  }
}
