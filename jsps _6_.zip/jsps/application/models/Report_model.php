<?php
if(!defined('BASEPATH')) exit('Hacking Attempt : Get Out of the system ..!');

class Report_model extends CI_Model

{

public function __construct()

{

parent::__construct();

}

public function list_common($table,$limit = null, $offset = null)
{
        $this->db->select('*');
 		$this->db->from($table);
 		$this->db->where('flag','0');
		 if (!empty($limit)) {
			$this->db->limit($limit, $offset);
		  }
		$query = $this->db->get();
		$result = $query->result_array();
		return $result;
}
public function report_data($table, $where, $id, $limit = null, $offset = null)
{
  $this->db->select('id');
  $this->db->from($table);
  $this->db->where($where, $id);

  if (!empty($limit)) {
	$this->db->limit($limit, $offset);
  }

  $query = $this->db->get();
  $result = $query->num_rows();
  return $result;
}

public function renewal_report()
{
      $this->db->select('sub_desposition.form_id,sub_desposition.policy_no,sub_desposition.desposition_id,sub_desposition.sub_desposition_name,sub_desposition.remark as sub_remark,sub_desposition.action,sub_desposition.action,sub_desposition.condition,sub_desposition.module,form.*');
			$this->db->from('sub_desposition');
			$this->db->join('form', 'sub_desposition.form_id = form.id', 'inner');
			$query = $this->db->get();
			$result = $query->result_array();
			return $result;
}
  
   
}


